%% LoCoS-R v1.1
% 2016-10-04
% Authors: Lukas Utz | Lorenzo Pasquini
% TUM Neuroimaging Center, Munich, Germany
%%

function SearchLightOrth(files,params)
    %% input
    %  files                   | struct
    %        .subjectfile      | * char
    %        .modalityfilep    | * char
    %        .modalityfilei    | * char
    %        .maskfile         |   char
    %  params                  | struct
    %        .outpath          | * char
    %        .search_radius    | * int
    %        .min_vox          | * int
    %        .corr_type        | * cell
    %        .write_imgs       | * bool
    %        .write_output     | * bool
    %        .modp_optname     | * cell
    %        .modi_optname     | * cell
    %        .zscore_modp      | * bool
    %        .zscore_modi      | * bool
    %        .use_modp_mask    | * bool
    %        .use_modi_mask    | * bool
    %        .mask_threshold   | * double
    %        .thresh_modp_low  | * double
    %        .thresh_modp_high | * double
    %        .thresh_modi_low  | * double
    %        .thresh_modi_high | * double

    [sub_names, sub_includes] = sl_readInputfile(files.subjectfile,1);
    [modp_files, ~]           = sl_readInputfile(files.modalityfilep,0);
    [modi_files, ~]           = sl_readInputfile(files.modalityfilei,0);
    if isfield(files, 'maskfile')
        isset_mask_files      = 1;
        [mask_files, ~]       = sl_readInputfile(files.maskfile,0);
    else
        isset_mask_files      = 0;
        params.mask_threshold = -Inf;
    end
    
    errors = {};
    if (isempty(sub_names))
        errors{end+1} = 'Missing values in the subject file';
    end
    if (isempty(modp_files))
        errors{end+1} = sprintf('Missing values in the %s file', params.modp_optname);
    end
    if (isempty(modi_files))
        errors{end+1} = sprintf('Missing values in the %s file', params.modi_optname);
    end
    
    if (~isempty(errors))
        warndlg(errors, 'Input error');
        return;
    end
   
    [~,results_name] = fileparts(params.outpath);
    
    sl_writeParamsTxt(files, params);
    
    params.remove_global = 0; % removed from gui, disable
    
    if params.write_imgs
        r_img_dir = sl_mkdirifnotexist(fullfile(params.outpath, 'R_images'));
        z_img_dir = sl_mkdirifnotexist(fullfile(params.outpath, 'Z_images'));
        if params.remove_global
            r_img_glb_dir = sl_mkdirifnotexist(fullfile(params.outpath, 'R_images_global'));
            z_img_glb_dir = sl_mkdirifnotexist(fullfile(params.outpath, 'Z_images_global'));
        end
    end

    if params.write_output
        output_dir = sl_mkdirifnotexist(fullfile(params.outpath, 'Info_Plots'));
    end
    
    subinclude_ids = find(cell2mat(cellfun(@str2num,sub_includes(:),'un',0)));
    nsub           = max(subinclude_ids);
    globalrs       = zeros(nsub,1);
    globalps       = zeros(nsub,1);
    netsize        = zeros(nsub,1);
    
    iimg = 0;
    nimg = 2;
    if params.remove_global
        nimg = 4;
    end
    nimg = nimg * length(subinclude_ids);
    
    sl_multiwaitbar('CloseAll');
    sl_multiwaitbar('Subjects', 0, 'Color', [0.2 0.9 0.3]);
    sl_multiwaitbar('--- orthogonalizing', 0, 'Color', [1.0 0.4 0.0]);
    sl_multiwaitbar('--- rLocal voxel loop', 0, 'Color', [1.0 0.4 0.0]);
    if params.write_imgs
        sl_multiwaitbar('--- write imgs', 0, 'Color', [0.1 0.5 0.8]);
    end
    if params.write_output
        sl_multiwaitbar('--- plot info', 0, 'Color', [0.1 0.5 0.8]);
        sl_multiwaitbar('--- write info', 0, 'Color', [0.1 0.5 0.8]);
    end

    for sub = 1:length(subinclude_ids)

        isub = subinclude_ids(sub);
        csub = sub_names{isub};
        sl_multiwaitbar('Subjects', sub/length(subinclude_ids), 'Color', [0.2 0.9 0.3]);
        
        %% MASK DATA
        if isset_mask_files
            MaskImg  = mask_files{isub};
            mask_vol = spm_vol(MaskImg);
            VoxList  = sl_findn(single(spm_read_vols(mask_vol)));
            gm_vox   = single(spm_sample_vol(mask_vol,VoxList(:,1),VoxList(:,2),VoxList(:,3),0));
        else
            modp_vol = spm_vol(modp_files{isub});
            VoxList  = sl_findn(single(ones(modp_vol.dim)));
            gm_vox   = single(ones(size(VoxList,1),1));
        end

        %% MOD PIB DATA
        ModpImg  = modp_files{isub};
        modp_vol = spm_vol(ModpImg);
        modp_vox = single(spm_sample_vol(modp_vol,VoxList(:,1),VoxList(:,2),VoxList(:,3),0));

        %% MOD ICN DATA
        ModiImg  = modi_files{isub};
        modi_vol = spm_vol(ModiImg);
        modi_vox = single(spm_sample_vol(modi_vol,VoxList(:,1),VoxList(:,2),VoxList(:,3),0));
        
        % apply mask to both images
        igm = gm_vox > params.mask_threshold;
        if (params.use_modp_mask)
            ithresh = modp_vox >= params.thresh_modp_low & modp_vox <= params.thresh_modp_high & modp_vox ~= 0 & ~isnan(modp_vox);
            itotp = logical(ithresh.*igm);
            itoti = ones(length(igm), 1);
        elseif (params.use_modi_mask)
            ithresh = modi_vox >= params.thresh_modi_low & modi_vox <= params.thresh_modi_high & modi_vox ~= 0 & ~isnan(modi_vox);
            itotp = ones(length(igm), 1);
            itoti = logical(ithresh.*igm);
        else
            itotp = igm;
            itoti = igm;
        end
        
        itot = logical(itotp .* itoti);
        
        gm_vox          = gm_vox .* itot;
        gm_ids          = find(gm_vox);
        gm_vox_masked   = gm_vox(gm_ids);
        modp_vox        = modp_vox .* itot;
        modp_vox_masked = modp_vox(gm_ids); %#ok<*FNDSB>
        modi_vox        = modi_vox .* itot;
        modi_vox_masked = modi_vox(gm_ids);
        
        [globalrs(isub),globalps(isub)] = corr(modp_vox_masked, modi_vox_masked,'type',params.corr_type); % global corr
        netsize(isub)                   = length(modp_vox_masked);
        
        VoxList = VoxList(itot,:);
        tot_vox = size(VoxList,1);
        R_image = single(zeros(tot_vox,2));
        
        mod_orth_save = cell(2,4);

        for orth_step = 1:2 % loop over voxels twice if orthogonalizing
            sl_multiwaitbar('--- orthogonalizing', orth_step/2, 'Color', [1.0 0.4 0.0]);
            orth_vectors = true; % true for orth
            perm_netdata = 0; % permute the ica data relative to the pib data? (control analysis)
            if orth_vectors
                if orth_step == 1
                    if params.zscore_modp,
                        modp_vox = sl_zvec(modp_vox(itot));
                    else
                        modp_vox = modp_vox(itot);
                    end
                    if params.zscore_modi,
                        modi_vox = sl_zvec(modi_vox(itot));
                    else
                        modi_vox = modi_vox(itot);
                    end
                    op = modp_vox;
                    oi = modi_vox;
                    x = sl_spm_orth([ones(nnz(itot),1)./sqrt(nnz(itot)) modp_vox./norm(modp_vox) modi_vox./norm(modi_vox)],'pad');
                    modp_vox = x(:,2);
                    if perm_netdata
                        modi_vox = x(randperm(size(x,1)),3); %#ok<*UNRCH>
                    else
                        modi_vox = x(:,3);
                    end
                    mod_orth_save{orth_step,1} = op;
                    mod_orth_save{orth_step,2} = oi;
                    mod_orth_save{orth_step,3} = modp_vox;
                    mod_orth_save{orth_step,4} = modi_vox;
                else
                    modp_vox = op; % clear op
                    modi_vox = oi; % clear oi
                    x = sl_spm_orth([ones(nnz(itot),1)./sqrt(nnz(itot)) modi_vox./norm(modi_vox) modp_vox./norm(modp_vox)],'pad');
                    modp_vox = x(:,3);
                    if perm_netdata
                        modi_vox = x(randperm(size(x,1)),2);
                    else
                        modi_vox = x(:,2);
                    end
                    mod_orth_save{orth_step,3} = modp_vox;
                    mod_orth_save{orth_step,4} = modi_vox;
                end
            else
                if params.zscore_modp,
                    modp_vox = sl_zvec(modp_vox(itot));
                else
                    modp_vox =         modp_vox(itot);
                end
                if params.zscore_modi,
                    modi_vox = sl_zvec(modi_vox(itot));
                else
                    modi_vox =         modi_vox(itot);
                end
            end
            
            % Voxel Loop
            tot_vox = size(VoxList,1);
            dim     = [abs(modp_vol.mat(1,1)) abs(modp_vol.mat(2,2)) abs(modp_vol.mat(3,3))];
            for voxel = 1:tot_vox, % calculate rLOCAL here (for each voxel in network)
                if (mod(voxel, floor(tot_vox/10)) == 0)
                    sl_multiwaitbar('--- rLocal voxel loop', voxel/tot_vox, 'Color', [1.0 0.4 0.0]);
                end
                CurrentVox = VoxList(voxel,:);
                dists = ((dim(1)*(CurrentVox(1) - VoxList(:,1))).^2 + ...
                         (dim(2)*(CurrentVox(2) - VoxList(:,2))).^2 + ...
                         (dim(3)*(CurrentVox(3) - VoxList(:,3))).^2);

                roi_index = find(sqrt(dists) < params.search_radius);
                vox_count = size(roi_index);

                if max(vox_count) >= params.min_vox
                    zvec_roi = 0;
                    if zvec_roi
                        r_tmp = corr(sl_zvec(modi_vox(roi_index)),sl_zvec(modp_vox(roi_index)),'type',params.corr_type); % local corr
                    else
                        r_tmp = corr(modi_vox(roi_index),modp_vox(roi_index),'type',params.corr_type);
                    end
                    R_image(voxel,orth_step) = r_tmp;
                    clear vox_count r_tmp
                end;
            end; % voxel loop
        end % for orth_step
        
        % average across the two orthogonalization steps
        use_pca = 0;
        if use_pca % using PCA
            [coeff score] = princomp(R_image);
            R_image       = score(:,1);
            clear score;
        else % using mean (almost identical results)
            R_image       = mean(R_image,2);
        end

        if params.write_imgs
            pib_vol = spm_vol(modp_files{isub});
            image_name = sprintf('%s_%s_%s.nii', csub, results_name, params.corr_type);
            nvox = length(VoxList(:,1));
            
            iimg = iimg + 1;
            sl_multiwaitbar('--- write imgs', iimg/nimg, 'Color', [0.1 0.5 0.8]);
            % write mean Z image
            Z_image = atanh(R_image);
            writevals = zeros(pib_vol.dim);
            for i = 1:nvox
                writevals(VoxList(i,1), VoxList(i,2), VoxList(i,3))  = 1.0*Z_image(i);
            end
            vol         = pib_vol;
            vol         = rmfield(vol,'pinfo');
            vol.fname   = fullfile(z_img_dir,image_name);
            vol.descrip = 'correlation map - Z-scored';
            spm_write_vol(vol,writevals);

            iimg = iimg + 1;
            sl_multiwaitbar('--- write imgs', iimg/nimg, 'Color', [0.1 0.5 0.8]);
            % write mean R image
            writevals = zeros(pib_vol.dim);
            for i = 1:nvox
                writevals(VoxList(i,1), VoxList(i,2), VoxList(i,3))  = 1.0*R_image(i);
            end
            vol         = pib_vol;
            vol         = rmfield(vol,'pinfo');
            vol.fname   = fullfile(r_img_dir,image_name);
            vol.descrip = 'correlation map - R-scored';
            spm_write_vol(vol,writevals);

            if params.remove_global
                
                R_image_global = R_image - globalrs(isub);

                iimg = iimg + 1;
                sl_multiwaitbar('--- write imgs', iimg/nimg, 'Color', [0.1 0.5 0.8]);
                % write mean Z image with global r correction
                Z_image_global = atanh(R_image_global);
                writevals = zeros(pib_vol.dim);
                for i = 1:nvox
                    writevals(VoxList(i,1), VoxList(i,2), VoxList(i,3))  = 1.0*Z_image_global(i);
                end
                vol         = pib_vol;
                vol         = rmfield(vol,'pinfo');
                vol.fname   = fullfile(z_img_glb_dir,image_name);
                vol.descrip = 'correlation map - global-r-corrected - Z-scored';
                spm_write_vol(vol,writevals);

                iimg = iimg + 1;
                sl_multiwaitbar('--- write imgs', iimg/nimg, 'Color', [0.1 0.5 0.8]);
                % write mean R image with global r correction
                writevals = zeros(pib_vol.dim);
                for i = 1:nvox
                    writevals(VoxList(i,1), VoxList(i,2), VoxList(i,3))  = 1.0*R_image_global(i);
                end
                vol         = pib_vol;
                vol         = rmfield(vol,'pinfo');
                vol.fname   = fullfile(r_img_glb_dir,image_name);
                vol.descrip = 'correlation map - global-r-corrected - R-scored';
                spm_write_vol(vol,writevals);

            end; % if global
        end; % if write_imgs

        % create info plots
        if params.write_output
            
            red   = [151/255  17/255  17/255];
            blue  = [ 17/255  61/255 151/255];
            green = [ 17/255 151/255  42/255];
            turq  = [ 17/255 151/255 149/255];
            red2  = [115/255  27/255  27/255];
            blue2 = [ 27/255  60/255 115/255];
            
            sl_multiwaitbar('--- plot info', isub/nsub, 'Color', [0.1 0.5 0.8]);

            

            f = figure('units', 'normalized', 'position', [0 1 1 1], 'Visible', 'off');
            set(gcf, 'color', 'w');

            subplot(2,3,1);
            nbins = range([floor(min(mod_orth_save{1,1})*10)/10, ceil(max(mod_orth_save{1,1})*10)/10]) * 20;
            hist(mod_orth_save{1,1}, nbins);
            set(get(gca,'child'), 'FaceColor', red, 'EdgeColor', 'k');
            xlabel(sprintf('%s vox', params.modp_optname));
            subplot(2,3,2);
            nbins = range([floor(min(mod_orth_save{1,2})*10)/10, ceil(max(mod_orth_save{1,2})*10)/10]) * 20;
            hist(mod_orth_save{1,2}, nbins);
            set(get(gca,'child'), 'FaceColor', blue, 'EdgeColor', 'k');
            xlabel(sprintf('%s vox', params.modi_optname));

            subplot(2,3,3);
            nbins = range([floor(min(gm_vox_masked)*10)/10, ceil(max(gm_vox_masked)*10)/10]) * 20;
            hist(gm_vox_masked, nbins);
            set(get(gca,'child'), 'FaceColor', green, 'EdgeColor', 'k');
            xlabel('Mask vox');

            subplot(2,3,4);
            plot(mod_orth_save{1,1}, mod_orth_save{1,2}, '*');
            h = lsline;
            set(h(1),'color','k');
            xl = xlim();
            yl = ylim();
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('Rho: %.4f\np: %.2e', globalrs(isub), globalps(isub)));
            xlabel(sprintf('%s vox', params.modp_optname));
            ylabel(sprintf('%s vox', params.modi_optname));

            subplot(2,3,5);
            rimg_vox = R_image(R_image ~= 0);
            nbins = range([floor(min(rimg_vox)*10)/10, ceil(max(rimg_vox)*10)/10]) * 20;
            hist(rimg_vox, nbins);
            set(get(gca,'child'), 'FaceColor', turq, 'EdgeColor', 'k');
            xl = xlim();
            yl = ylim();
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('total vox: %i\nnon-zero vox: %i', length(R_image), length(rimg_vox)));
            xlabel('rLocal');
            
            export_fig(fullfile(output_dir, sprintf('%s_%s_Info.png', csub, results_name)), '-a1');
            close(f);
            
            
            
            f = figure('units', 'normalized', 'position', [0 1 1 1], 'Visible', 'off');
            set(gcf, 'color', 'w');

            subplot(2,4,1);
            m1 = mod_orth_save{1,1}; m2 = mod_orth_save{1,2};
            plot(m1, m2, '*', 'Color', [148/255 19/255 32/255]);
            h = lsline;
            set(h(1),'color','k');
            xl = xlim();
            yl = ylim();
            [r,p] = corr(m1, m2, 'type', 'Pearson');
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('Rho: %.4f\np: %.2e', r, p));
            xlabel(sprintf('%s before orthogonalization', params.modp_optname));
            ylabel(sprintf('%s before orthogonalization', params.modi_optname));
            
            subplot(2,4,2);
            m1 = mod_orth_save{1,3}; m2 = mod_orth_save{1,4};
            plot(m1, m2, '*', 'Color', [55/255 55/255 110/255]);
            h = lsline;
            set(h(1),'color','k');
            xl = xlim();
            yl = ylim();
            [r,p] = corr(m1, m2, 'type', 'Pearson');
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('Rho: %.4f\np: %.2e', r, p));
            xlabel(sprintf('%s after orthogonalization %s', params.modp_optname, params.modi_optname));
            ylabel(sprintf('%s after orthogonalization %s', params.modi_optname, params.modi_optname));
            
            subplot(2,4,3);
            m1 = mod_orth_save{1,1}; m2 = mod_orth_save{1,3};
            plot(m1, m2, '*', 'Color', [65/255 137/255 55/255]);
            h = lsline;
            set(h(1),'color','k');
            xl = xlim();
            yl = ylim();
            [r,p] = corr(m1, m2, 'type', 'Pearson');
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('Rho: %.4f\np: %.2e', r, p));
            xlabel(sprintf('%s before orthogonalization', params.modp_optname));
            ylabel(sprintf('%s after orthogonalization %s', params.modp_optname, params.modi_optname));
            
            subplot(2,4,4);
            m1 = mod_orth_save{1,2}; m2 = mod_orth_save{1,4};
            plot(m1, m2, '*', 'Color', [65/255 137/255 55/255]);
            h = lsline;
            set(h(1),'color','k');
            xl = xlim();
            yl = ylim();
            [r,p] = corr(m1, m2, 'type', 'Pearson');
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('Rho: %.4f\np: %.2e', r, p));
            xlabel(sprintf('%s before orthogonalization', params.modi_optname));
            ylabel(sprintf('%s after orthogonalization %s', params.modi_optname, params.modi_optname));
            
            subplot(2,4,6);
            m1 = mod_orth_save{2,3}; m2 = mod_orth_save{2,4};
            plot(m1, m2, '*', 'Color', [55/255 55/255 110/255]);
            h = lsline;
            set(h(1),'color','k');
            xl = xlim();
            yl = ylim();
            [r,p] = corr(m1, m2, 'type', 'Pearson');
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('Rho: %.4f\np: %.2e', r, p));
            xlabel(sprintf('%s after orthogonalization %s', params.modp_optname, params.modp_optname));
            ylabel(sprintf('%s after orthogonalization %s', params.modi_optname, params.modp_optname));
            
            subplot(2,4,7);
            m1 = mod_orth_save{1,1}; m2 = mod_orth_save{2,3};
            plot(m1, m2, '*', 'Color', [65/255 137/255 55/255]);
            h = lsline;
            set(h(1),'color','k');
            xl = xlim();
            yl = ylim();
            [r,p] = corr(m1, m2, 'type', 'Pearson');
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('Rho: %.4f\np: %.2e', r, p));
            xlabel(sprintf('%s before orthogonalization', params.modp_optname));
            ylabel(sprintf('%s after orthogonalization %s', params.modp_optname, params.modp_optname));
            
            subplot(2,4,8);
            m1 = mod_orth_save{1,2}; m2 = mod_orth_save{2,4};
            plot(m1, m2, '*', 'Color', [65/255 137/255 55/255]);
            h = lsline;
            set(h(1),'color','k');
            xl = xlim();
            yl = ylim();
            [r,p] = corr(m1, m2, 'type', 'Pearson');
            text(xl(1)+range(xl)*0.05, yl(2)-range(yl)*0.1, sprintf('Rho: %.4f\np: %.2e', r, p));
            xlabel(sprintf('%s before orthogonalization', params.modi_optname));
            ylabel(sprintf('%s after orthogonalization %s', params.modi_optname, params.modp_optname));
            
            export_fig(fullfile(output_dir, sprintf('%s_%s_Ortho_Info.png', csub, results_name)), '-a1');
            close(f);
            
            
            
            f = figure('units', 'normalized', 'position', [0 1 1 1], 'Visible', 'off');
            set(gcf, 'color', 'w');
            
            subplot(2,4,1);
            hist(mod_orth_save{1,1}, 50);
            xlabel(sprintf('%s before orthogonalization', params.modp_optname));
            set(get(gca,'child'), 'FaceColor', red, 'EdgeColor', 'k');
            
            subplot(2,4,2);
            hist(mod_orth_save{1,2}, 50);
            xlabel(sprintf('%s before orthogonalization', params.modi_optname));
            set(get(gca,'child'), 'FaceColor', blue, 'EdgeColor', 'k');
            
            subplot(2,4,3);
            hist(mod_orth_save{1,3}, 50);
            xlabel(sprintf('%s after orthogonalization %s', params.modp_optname, params.modi_optname));
            set(get(gca,'child'), 'FaceColor', red2, 'EdgeColor', 'k');
            
            subplot(2,4,4);
            hist(mod_orth_save{1,4}, 50);
            xlabel(sprintf('%s after orthogonalization %s', params.modi_optname, params.modi_optname));
            set(get(gca,'child'), 'FaceColor', blue2, 'EdgeColor', 'k');
            
            subplot(2,4,7);
            hist(mod_orth_save{2,3}, 50);
            xlabel(sprintf('%s after orthogonalization %s', params.modp_optname, params.modp_optname));
            set(get(gca,'child'), 'FaceColor', red2, 'EdgeColor', 'k');
            
            subplot(2,4,8);
            hist(mod_orth_save{2,4}, 50);
            xlabel(sprintf('%s after orthogonalization %s', params.modi_optname, params.modp_optname));
            set(get(gca,'child'), 'FaceColor', blue2, 'EdgeColor', 'k');

            export_fig(fullfile(output_dir, sprintf('%s_%s_Ortho_Hist_Info.png', csub, results_name)), '-a1');
            close(f);
            
            
        end % if write_output
        
    end % for subjects
    
    % write output txt-file
    if params.write_output
        
        sl_multiwaitbar('--- write info', 1, 'Color', [0.1 0.5 0.8]);
        
        f = fopen(fullfile(output_dir, 'info.txt'), 'w');
        fprintf(f, 'Subject\tnetsize\tr (p)\tzr\tSE_zr\n');
        fprintf(f, '%s\n', '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
        zglobalrs = 0.5 .* log((1+globalrs)./(1-globalrs));
        sezglobalrs = 1./sqrt(netsize-3);
        for sub = 1:length(subinclude_ids)
            isub = subinclude_ids(sub);
            fprintf(f, '%s\t%i\t%.4f (%.2e)\t%.4f\t%.4f\n', sub_names{isub}, netsize(isub), globalrs(isub), globalps(isub), zglobalrs(isub), sezglobalrs(isub));
        end
        fclose(f);
        
    end % if write_output
    
    sl_multiwaitbar('CLOSEALL');

end
