%% LoCoS-R v1.1
% 2016-10-04
% Authors: Lukas Utz | Lorenzo Pasquini
% TUM Neuroimaging Center, Munich, Germany
%%

function varargout = SearchLightOrthGUI(varargin)
% SEACHLIGHTORTHGUI MATLAB code for SearchLightOrthGUI.fig
%      SEACHLIGHTORTHGUI, by itself, creates a new SEACHLIGHTORTHGUI or raises the existing
%      singleton*.
%
%      H = SEACHLIGHTORTHGUI returns the handle to a new SEACHLIGHTORTHGUI or the handle to
%      the existing singleton*.
%
%      SEACHLIGHTORTHGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SEACHLIGHTORTHGUI.M with the given input arguments.
%
%      SEACHLIGHTORTHGUI('Property','Value',...) creates a new SEACHLIGHTORTHGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SearchLightOrthGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SearchLightOrthGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SearchLightOrthGUI

% Last Modified by GUIDE v2.5 07-Apr-2017 14:24:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SearchLightOrthGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @SearchLightOrthGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SearchLightOrthGUI is made visible.
function SearchLightOrthGUI_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<*INUSL>
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SearchLightOrthGUI (see VARARGIN)

% Choose default command line output for SearchLightOrthGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

global files params numreq required maskchanged;
files         = struct;
params        = struct;
maskchanged   = 0;
numreq        = 4;
required.subj = 1;
required.modp = 1;
required.modi = 1;
required.mask = 0;
required.outp = 1;

if (check_required(required) == numreq)
    set(handles.run_pushbutton,'enable','on');
end


% UIWAIT makes SearchLightOrthGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = SearchLightOrthGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function subjectfile_edit_Callback(hObject, eventdata, handles) %#ok<*DEFNU,*INUSD>
% hObject    handle to subjectfile_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of subjectfile_edit as text
%        str2double(get(hObject,'String')) returns contents of subjectfile_edit as a double


% --- Executes during object creation, after setting all properties.
function subjectfile_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to subjectfile_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in subjectfile_pushbutton.
function subjectfile_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to subjectfile_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[Filename,Pathname] = uigetfile({'*.txt', 'Text files (*.txt)'; '*.*', 'All files (*.*)'},'Select the subjects file');
path = fullfile(Pathname,Filename);
global files required numreq;
files.subjectfile = path;
required.subj = 1;
if (check_required(required) == numreq)
    set(handles.run_pushbutton,'enable','on');
end
t = 60;
if length(path) > t %#ok<*ISMT>
    path = strcat('[...]', path( length(path)-t:end ) );
end
set(handles.subjectfile_edit, 'String', path);


function modalityp_edit_Callback(hObject, eventdata, handles)
% hObject    handle to modalityp_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of modalityp_edit as text
%        str2double(get(hObject,'String')) returns contents of modalityp_edit as a double


% --- Executes during object creation, after setting all properties.
function modalityp_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modalityp_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in modalityp_pushbutton.
function modalityp_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to modalityp_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[Filename,Pathname] = uigetfile({'*.txt', 'Text files (*.txt)'; '*.*', 'All files (*.*)'},'Select the modality P file');
path = fullfile(Pathname,Filename);
global files required numreq;
files.modalityfilep = path;
required.modp = 1;
if (check_required(required) == numreq)
    set(handles.run_pushbutton,'enable','on');
end
t = 60;
if length(path) > t
    path = strcat('[...]', path( length(path)-t:end ) );
end
set(handles.modalityp_edit, 'String', path);


function modalityi_edit_Callback(hObject, eventdata, handles)
% hObject    handle to modalityi_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of modalityi_edit as text
%        str2double(get(hObject,'String')) returns contents of modalityi_edit as a double


% --- Executes during object creation, after setting all properties.
function modalityi_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modalityi_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in modalityi_pushbutton.
function modalityi_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to modalityi_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[Filename,Pathname] = uigetfile({'*.txt', 'Text files (*.txt)'; '*.*', 'All files (*.*)'},'Select the modality I file');
path = fullfile(Pathname,Filename);
global files required numreq;
files.modalityfilei = path;
required.modi = 1;
if (check_required(required) == numreq)
    set(handles.run_pushbutton,'enable','on');
end
t = 60;
if length(path) > t
    path = strcat('[...]', path( length(path)-t:end ) );
end
set(handles.modalityi_edit, 'String', path);


function maskfile_edit_Callback(hObject, eventdata, handles)
% hObject    handle to maskfile_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maskfile_edit as text
%        str2double(get(hObject,'String')) returns contents of maskfile_edit as a double


% --- Executes during object creation, after setting all properties.
function maskfile_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maskfile_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in maskfile_pushbutton.
function maskfile_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to maskfile_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[Filename,Pathname] = uigetfile({'*.txt', 'Text files (*.txt)'; '*.*', 'All files (*.*)'},'Select the mask file');
path = fullfile(Pathname,Filename);
global files required numreq maskchanged;
files.maskfile = path;
maskchanged = 1;
required.mask = 1;
if (check_required(required) == numreq)
    set(handles.run_pushbutton,'enable','on');
end
t = 60;
if length(path) > t
    path = strcat('[...]', path( length(path)-t:end ) );
end
set(handles.maskfile_edit, 'String', path);


function modalityp_lowbound_edit_Callback(hObject, eventdata, handles)
% hObject    handle to modalityp_lowbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of modalityp_lowbound_edit as text
%        str2double(get(hObject,'String')) returns contents of modalityp_lowbound_edit as a double


% --- Executes during object creation, after setting all properties.
function modalityp_lowbound_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modalityp_lowbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function modalityp_upbound_edit_Callback(hObject, eventdata, handles)
% hObject    handle to modalityp_upbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of modalityp_upbound_edit as text
%        str2double(get(hObject,'String')) returns contents of modalityp_upbound_edit as a double


% --- Executes during object creation, after setting all properties.
function modalityp_upbound_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modalityp_upbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function modalityi_lowbound_edit_Callback(hObject, eventdata, handles)
% hObject    handle to modalityi_lowbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of modalityi_lowbound_edit as text
%        str2double(get(hObject,'String')) returns contents of modalityi_lowbound_edit as a double


% --- Executes during object creation, after setting all properties.
function modalityi_lowbound_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modalityi_lowbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function modalityi_upbound_edit_Callback(hObject, eventdata, handles)
% hObject    handle to modalityi_upbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of modalityi_upbound_edit as text
%        str2double(get(hObject,'String')) returns contents of modalityi_upbound_edit as a double


% --- Executes during object creation, after setting all properties.
function modalityi_upbound_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modalityi_upbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in modalityp_checkbox.
function modalityp_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to modalityp_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if (get(hObject,'value') == get(hObject,'Max'))
    % enable modp
    set(handles.modalityp_lowbound_edit,'enable','on');
    set(handles.modalityp_upbound_edit, 'enable','on');
else
    % disable modp
    set(handles.modalityp_lowbound_edit,'enable','off');
    set(handles.modalityp_upbound_edit, 'enable','off');
end


% --- Executes on button press in modalityi_checkbox.
function modalityi_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to modalityi_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if (get(hObject,'value') == get(hObject,'Max'))
    % enable modi
    set(handles.modalityi_lowbound_edit,'enable','on');
    set(handles.modalityi_upbound_edit, 'enable','on');
else
    % disable modi
    set(handles.modalityi_lowbound_edit,'enable','off');
    set(handles.modalityi_upbound_edit, 'enable','off');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over subjectfile_pushbutton.
function subjectfile_pushbutton_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to subjectfile_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on modalityp_lowbound_edit and none of its controls.
function modalityp_lowbound_edit_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to modalityp_lowbound_edit (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


function outpath_edit_Callback(hObject, eventdata, handles)
% hObject    handle to outpath_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of outpath_edit as text
%        str2double(get(hObject,'String')) returns contents of outpath_edit as a double


% --- Executes during object creation, after setting all properties.
function outpath_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outpath_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in outpath_pushbutton.
function outpath_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to outpath_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
dname = uigetdir(pwd, 'Select outpath');
global params required numreq;
params.outpath = dname;
required.outp = 1;
if (check_required(required) == numreq)
    set(handles.run_pushbutton,'enable','on');
end
t = 60;
if length(dname) > t
    dname = strcat('[...]', dname( length(dname)-t:end ) );
end
set(handles.outpath_edit, 'String', dname);


function searchradius_edit_Callback(hObject, eventdata, handles)
% hObject    handle to searchradius_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of searchradius_edit as text
%        str2double(get(hObject,'String')) returns contents of searchradius_edit as a double


% --- Executes during object creation, after setting all properties.
function searchradius_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to searchradius_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in correlation_listbox.
function correlation_listbox_Callback(hObject, eventdata, handles)
% hObject    handle to correlation_listbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns correlation_listbox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from correlation_listbox


% --- Executes during object creation, after setting all properties.
function correlation_listbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to correlation_listbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in zscoremodp_checkbox.
function zscoremodp_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to zscoremodp_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of zscoremodp_checkbox


% --- Executes on button press in zscoremodi_checkbox.
function zscoremodi_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to zscoremodi_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of zscoremodi_checkbox


% --- Executes on button press in removeglobal_checkbox.
function removeglobal_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to removeglobal_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of removeglobal_checkbox


% --- Executes on button press in writeimg_checkbox.
function writeimg_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to writeimg_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of writeimg_checkbox


function reqsum = check_required(req)
    req = struct2cell(req);
    reqsum = sum([req{:}]);


function maskfile_thresh_edit_Callback(hObject, eventdata, handles)
% hObject    handle to maskfile_thresh_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maskfile_thresh_edit as text
%        str2double(get(hObject,'String')) returns contents of maskfile_thresh_edit as a double


% --- Executes during object creation, after setting all properties.
function maskfile_thresh_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maskfile_thresh_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over modalityp_lowbound_edit.
function modalityp_lowbound_edit_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to modalityp_lowbound_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in writefile_checkbox.
function writefile_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to writefile_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of writefile_checkbox
if (get(hObject,'value') == get(hObject,'Max'))
    % enable modp
    set(handles.modalityp_optname_edit, 'enable','on');
    set(handles.modalityi_optname_edit, 'enable','on');
else
    % disable modp
    set(handles.modalityp_optname_edit, 'enable','off');
    set(handles.modalityi_optname_edit, 'enable','off');
end


function minvox_edit_Callback(hObject, eventdata, handles)
% hObject    handle to minvox_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minvox_edit as text
%        str2double(get(hObject,'String')) returns contents of minvox_edit as a double


% --- Executes during object creation, after setting all properties.
function minvox_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minvox_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function modalityp_optname_edit_Callback(hObject, eventdata, handles)
% hObject    handle to modalityp_optname_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of modalityp_optname_edit as text
%        str2double(get(hObject,'String')) returns contents of modalityp_optname_edit as a double


% --- Executes during object creation, after setting all properties.
function modalityp_optname_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modalityp_optname_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function modalityi_optname_edit_Callback(hObject, eventdata, handles)
% hObject    handle to modalityi_optname_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of modalityi_optname_edit as text
%        str2double(get(hObject,'String')) returns contents of modalityi_optname_edit as a double


% --- Executes during object creation, after setting all properties.
function modalityi_optname_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to modalityi_optname_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in run_pushbutton.
function run_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to run_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global files params maskchanged;
% check if mask-data is given, if both modality checkboxes are unchecked
if (~get(handles.modalityp_checkbox,'Value') && ~get(handles.modalityi_checkbox,'Value') && ~maskchanged)
    return;
end
params.use_modp_mask = 0;
if (get(handles.modalityp_checkbox,'Value'))
    params.use_modp_mask = 1;
    if (length(get(handles.modalityp_lowbound_edit,'Value')) > 0)
        params.thresh_modp_low = str2double(get(handles.modalityp_lowbound_edit,'String'));
    else
        params.thresh_modp_low = -Inf;
    end
    if (length(get(handles.modalityp_upbound_edit,'Value')) > 0)
        params.thresh_modp_high = str2double(get(handles.modalityp_upbound_edit,'String'));
    else
        params.thresh_modp_high = -Inf;
    end
end
params.use_modi_mask = 0;
if (get(handles.modalityi_checkbox,'Value'))
    params.use_modi_mask = 1;    
    if (length(get(handles.modalityi_lowbound_edit,'Value')) > 0)
        params.thresh_modi_low = str2double(get(handles.modalityi_lowbound_edit,'String'));
    else
        params.thresh_modi_low = -Inf;
    end
    if (length(get(handles.modalityi_upbound_edit,'Value')) > 0)
        params.thresh_modi_high = str2double(get(handles.modalityi_upbound_edit,'String'));
    else
        params.thresh_modi_high = -Inf;
    end
end

params.mask_threshold = str2double(get(handles.maskfile_thresh_edit,'String'));

params.search_radius = str2double(get(handles.searchradius_edit,'String'));
if (isempty(params.search_radius))
    return;
end
params.min_vox = str2double(get(handles.minvox_edit,'String'));
if (isempty(params.min_vox))
    return;
end
corr_vals = get(handles.correlation_listbox,'String');
params.corr_type     = corr_vals{get(handles.correlation_listbox,'Value')};
params.zscore_modp   = get(handles.zscoremodp_checkbox,'Value');
params.zscore_modi   = get(handles.zscoremodi_checkbox,'Value');
params.write_imgs    = get(handles.writeimg_checkbox,'Value');
params.write_output  = get(handles.writefile_checkbox,'Value');
if params.write_output
    params.modp_optname = get(handles.modalityp_optname_edit,'String');
    params.modi_optname = get(handles.modalityi_optname_edit,'String');
    if (strcmp(params.modp_optname, 'Name of modality 1 (optional)') == 1)
        params.modp_optname = 'Modality 1';
    end
    if (strcmp(params.modi_optname, 'Name of modality 2 (optional)') == 1)
        params.modi_optname = 'Modality 2';
    end
else
    params.modp_optname = 'Modality 1';
    params.modi_optname = 'Modality 2';
end

SearchLightOrth(files,params);
