%% LoCoS-R v1.1
% 2016-10-04
% Authors: Lukas Utz | Lorenzo Pasquini
% TUM Neuroimaging Center, Munich, Germany
%%

function dir = sl_mkdirifnotexist(dir)
    if ~isequal(exist(dir, 'dir'), 7)
        mkdir(dir);
    end
end
