%% LoCoS-R v1.1
% 2016-10-04
% Authors: Lukas Utz | Lorenzo Pasquini
% TUM Neuroimaging Center, Munich, Germany
%%

function [col1, col2] = sl_readInputfile(f,issubjectfile)

    % read in file
    if (issubjectfile)
        sl = textscan(fopen(fullfile(f)), '%s %s');
    else
        sl = textscan(fopen(fullfile(f)), '%s');
    end
    
    % skip first lines with column descriptions
    col1 = sl{1};
    if (issubjectfile)
        col2 = sl{2};
    else
        col2 = false;
    end
    for i = 1:length(sl{1})
        col1(1) = [];
        if (issubjectfile)
            col2(1) = [];
        end
        if (strncmpi(sl{1}{i},'%',1))
            break;
        end
    end
    
end
