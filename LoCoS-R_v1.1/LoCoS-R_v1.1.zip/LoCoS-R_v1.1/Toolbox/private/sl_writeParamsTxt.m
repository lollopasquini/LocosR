%% LoCoS-R v1.1
% 2016-10-04
% Authors: Lukas Utz | Lorenzo Pasquini
% TUM Neuroimaging Center, Munich, Germany
%%

function sl_writeParamsTxt(files, params)
    % write out the parameter of the current analysis

    sl_mkdirifnotexist(params.outpath);
    ftxt = fopen(fullfile(params.outpath, 'params.txt'), 'w');
    
    fprintf(ftxt, '%s\t\t\t\t%s\n', 'Subjects', files.subjectfile);
    fprintf(ftxt, '%s\t\t\t\t%s\n', 'Modality PIB', files.modalityfilep);
    fprintf(ftxt, '%s\t\t\t\t%s\n', 'Modality ICN', files.modalityfilei);
    if isfield(files, 'maskfile')
        fprintf(ftxt, '%s\t\t\t\t\t%s\n', 'Mask', files.maskfile);
    else
        fprintf(ftxt, '%s\t\t\t\t\t%s\n', 'Mask', 'None');
    end
    
    fprintf(ftxt, '\n');
    
    fprintf(ftxt, '%s\t\t%i\n', 'Use Modality PIB as mask', params.use_modp_mask);
    if (params.use_modp_mask)
        fprintf(ftxt, '--> lower bound: %.4f, upper bound:\t%.4f\n', params.thresh_modp_low, params.thresh_modp_high);
    end
    fprintf(ftxt, '%s\t\t%i\n', 'Use Modality ICN as mask', params.use_modi_mask);
    if (params.use_modi_mask)
        fprintf(ftxt, '--> lower bound: %.4f, upper bound:\t%.4f\n', params.thresh_modi_low, params.thresh_modi_high);
    end
    
    fprintf(ftxt, '\n');
    
    fprintf(ftxt, '%s\t\t\t\t%.4f\n', 'Mask threshold', params.mask_threshold);
    
    fprintf(ftxt, '\n');
    
    fprintf(ftxt, '%s\t\t\t\t%i\n', 'Radius [mm]', params.search_radius);
    fprintf(ftxt, '%s\t\t\t%i\n',   'Minimal voxel number', params.min_vox);
    fprintf(ftxt, '%s\t\t\t%s\n',   'Correlation type', params.corr_type);
    
    fprintf(ftxt, '\n');
    
    fprintf(ftxt, '%s\t\t\t%i\n',   'Zscore Modality PIB', params.zscore_modp);
    fprintf(ftxt, '%s\t\t\t%i\n',   'Zscore Modality ICN', params.zscore_modi);
    
    fprintf(ftxt, '\n');
    
    fprintf(ftxt, '%s\t\t\t%i\n',   'Write output images', params.write_imgs);
    fprintf(ftxt, '%s\t\t\t%i\n',   'Write output plot/info', params.write_output);
    
    fclose(ftxt);

end
