%% LoCoS-R v1.1
% 2016-10-04
% Authors: Lukas Utz | Lorenzo Pasquini
% TUM Neuroimaging Center, Munich, Germany
%%

function [z] = sl_zvec(x)
%[z] = zvec(x)
%zscore for vectors

z = (x - mean(x))./std(x);
end
